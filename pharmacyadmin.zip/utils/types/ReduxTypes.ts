export interface SpecialityInterface {
    SpecialitiesID: number
}
export interface UsersInterface {
    Users:  UsersInterface[];
}