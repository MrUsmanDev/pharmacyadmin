import React, { Suspense } from 'react'
import ProductList from './ProductList'

const page = () => {
  return (
    
      <ProductList />
  )
}

export default page