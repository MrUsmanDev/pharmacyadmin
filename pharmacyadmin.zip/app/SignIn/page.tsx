import React from 'react'
import LoginApp from './LoginApp'

const page = () => {
  return <LoginApp />
}

export default page