import Image from 'next/image'
import Main from './(SharedComponents)/Main'

export default function Home() {
  return  <Main />
}
